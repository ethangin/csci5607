//UMN CSCI 5607 2D Geometry Library Homework [HW0]
//TODO: For the 18 functions below, replace their sub function with a working version that matches the desciption.

#ifndef GEOM_LIB_H
#define GEOM_LIB_H

#include "pga.h"

//Displace a point p on the direction d
//The result is a point
Point2D move(Point2D p, Dir2D d){
  return Point2D(p.x + d.x, p.y + d.y);
}

//Compute the displacement vector between points p1 and p2
//The result is a direction 
Dir2D displacement(Point2D p1, Point2D p2){
  return Dir2D(p2.x-p1.x, p2.y-p1.y);
}

//Compute the distance between points p1 and p2
//The result is a scalar 
float dist(Point2D p1, Point2D p2){
  return sqrt( pow(p2.x-p1.x, 2.0) + pow(p2.y-p1.y, 2.0) );
}

//Compute the perpendicular distance from the point p the the line l
//The result is a scalar 
float dist(Line2D l, Point2D p){
  return (l.x*p.x + l.y*p.y + l.w) / sqrt(l.x*l.x + l.y*l.y);
}

//Compute the perpendicular distance from the point p the the line l
//The result is a scalar 
float dist(Point2D p, Line2D l){
  return (l.x*p.x + l.y*p.y + l.w) / sqrt(l.x*l.x + l.y*l.y);
}

//Compute the intersection point between lines l1 and l2
//You may assume the lines are not parallel
//The results is a a point that lies on both lines
Point2D intersect(Line2D l1, Line2D l2){
  MultiVector _l1 = MultiVector(0,l1.x,l1.y,l1.w,0,0,0,0);
  MultiVector _l2 = MultiVector(0,l2.x,l2.y,l2.w,0,0,0,0);
  MultiVector i = _l1.wedge(_l2);

  return Point2D( (i.yw/i.xy), (i.wx/i.xy) );
}

//Compute the line that goes through the points p1 and p2
//The result is a line 
Line2D join(Point2D p1, Point2D p2){
  MultiVector _p1 = MultiVector(0,0,0,0,p1.x,p1.y,1,0);
  MultiVector _p2 = MultiVector(0,0,0,0,p2.x,p2.y,1,0);

  MultiVector j = _p1.vee(_p2);
  return Line2D(j.x,j.y,j.w);
}

//Compute the projection of the point p onto line l
//The result is the closest point to p that lies on line l
Point2D project(Point2D p, Line2D l){
  MultiVector _p = MultiVector(0,0,0,0,p.x,p.y,1,0);
  MultiVector _l = MultiVector(0,l.x,l.y,l.w,0,0,0,0);
  return _l.dot(_p).times(_l);
}

//Compute the projection of the line l onto point p
//The result is a line that lies on point p in the same direction of l
Line2D project(Line2D l, Point2D p){
  MultiVector _p = MultiVector(0,0,0,0,p.x,p.y,1,0);
  MultiVector _l = MultiVector(0,l.x,l.y,l.w,0,0,0,0);
  return _l.dot(_p).times(_p);
}

//Compute the angle point between lines l1 and l2
//You may assume the lines are not parallel
//The results is a scalar
float angle(Line2D l1, Line2D l2){
  Line2D l1_norm = l1.normalized();
  Line2D l2_norm = l2.normalized();
  return acos(l1_norm.x*l2_norm.x + l1_norm.y*l2_norm.y);
}

//Compute if the line segment p1->p2 intersects the line segment a->b
//The result is a boolean
bool segmentSegmentIntersect(Point2D p1, Point2D p2, Point2D a, Point2D b){
  MultiVector _p1 = MultiVector(0,0,0,0,p1.x,p1.y,1,0);
  MultiVector _p2 = MultiVector(0,0,0,0,p2.x,p2.y,1,0);
  MultiVector _a = MultiVector(0,0,0,0,a.x,a.y,1,0);
  MultiVector _b = MultiVector(0,0,0,0,b.x,b.y,1,0);

  MultiVector l1 = _p1.vee(_p2);
  MultiVector l2 = _a.vee(_b);

  bool m = (_p1.vee(l2).s * _p2.vee(l2)) < 0;
  bool n = (_a.vee(l1).s * _b.vee(l1)) < 0;
  
  return (m && n);
}

//Compute if the point p lies inside the triangle t1,t2,t3
//Your code should work for both clockwise and counterclockwise windings
//The result is a bool
bool pointInTriangle(Point2D p, Point2D t1, Point2D t2, Point2D t3){
  MultiVector _p = MultiVector(0,0,0,0,p.x,p.y,1,0);
  MultiVector _t1 = MultiVector(0,0,0,0,t1.x,t1.y,1,0);
  MultiVector _t2 = MultiVector(0,0,0,0,t2.x,t2.y,1,0);
  MultiVector _t3 = MultiVector(0,0,0,0,t3.x,t3.y,1,0);
  
  MultiVector l1 = _t1.vee(_t2);
  MultiVector l2 = _t2.vee(_t3);
  MultiVector l3 = _t3.vee(_t1);
  bool a,b,c;

  a = _p.vee(l1).s > 0;
  b = _p.vee(l2).s > 0;
  c = _p.vee(l3).s > 0;
  return (a == b && a == c);
}

//Compute the area of the triangle t1,t2,t3
//The result is a scalar
float areaTriangle(Point2D t1, Point2D t2, Point2D t3){
  Dir2D v1 = Dir2D(t2.x-t1.x, t2.y-t1.y);
  Dir2D v2 = Dir2D(t3.x-t1.x, t3.y-t1.y);
  return 0.5*(v1.x*v2.y - v1.y*v2.x);
}

//Compute the distance from the point p to the triangle t1,t2,t3 as defined 
//by it's distance from the edge closest to p.
//The result is a scalar
float pointTriangleEdgeDist(Point2D p, Point2D t1, Point2D t2, Point2D t3){
  float a,b,c;
  Line2D l1 = join(t1,t2);
  Line2D l2 = join(t2,t3);
  Line2D l3 = join(t3,t1);

  a = dist(p,l1);
  b = dist(p,l2);
  c = dist(p,l3);
  
  if (abs(a) < abs(b)) {
    if (abs(a) < abs(c)) {
      return a;
    } else {
      return c;
    }
  } else {
    if (abs(b) < abs(c)) {
      return b;
    } else {
      return c;
    }
  }
}

//Compute the distance from the point p to the closest of three corners of
// the triangle t1,t2,t3
//The result is a scalar
float pointTriangleCornerDist(Point2D p, Point2D t1, Point2D t2, Point2D t3){
  float a,b,c;
  a = dist(p,t1);
  b = dist(p,t2);
  c = dist(p,t3);

  if (abs(a) < abs(b)) {
    if (abs(a) < abs(c)) {
      return a;
    } else {
      return c;
    }
  } else {
    if (abs(b) < abs(c)) {
      return b;
    } else {
      return c;
    }
  }
}

//Compute if the quad (p1,p2,p3,p4) is convex.
//Your code should work for both clockwise and counterclockwise windings
//The result is a boolean
bool isConvex_Quad(Point2D p1, Point2D p2, Point2D p3, Point2D p4){
  bool a,b,c,d;
  a = pointInTriangle(p4,p1,p2,p3);
  b = pointInTriangle(p1,p2,p3,p4);
  c = pointInTriangle(p2,p1,p4,p3);
  d = pointInTriangle(p3,p1,p2,p4);
  bool l = segmentSegmentIntersect(p1,p3,p2,p4);
    
  return (!a && !b && !c && !d && l);
}

//Compute the reflection of the point p about the line l
//The result is a point
Point2D reflect(Point2D p, Line2D l){
  MultiVector _p = MultiVector(0,0,0,0,p.x,p.y,1,0);
  MultiVector _l = MultiVector(0,l.x,l.y,l.w,0,0,0,0).normalized();

  MultiVector r = _p.add(_p.dot(_l).times(_l).mul(-2));
  return Point2D(r.yw/r.xy,r.wx/r.xy);
}

//Compute the reflection of the line d about the line l
//The result is a line
Line2D reflect(Line2D d, Line2D l){
  MultiVector _d = MultiVector(0,d.x,d.y,d.w,0,0,0,0);
  MultiVector _l = MultiVector(0,l.x,l.y,l.w,0,0,0,0).normalized();

  MultiVector r = _d.add(_d.dot(_l).times(_l).mul(-2));
  return Line2D(r.x,r.y,r.w);
}

#endif